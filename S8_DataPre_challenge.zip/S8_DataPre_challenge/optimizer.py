from __future__ import print_function
from ortools.constraint_solver import pywrapcp
from ortools.constraint_solver import routing_enums_pb2
import numpy as np
import pandas as pd

def haversine(lon1, lat1, lon2, lat2):
    from math import radians, cos, sin, asin, sqrt

    # convert decimal degrees to radians
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])

    # haversine formula
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * asin(sqrt(a))
    r = 6371 # Radio de la tierra en km.

    return c * r

def build_distance_matrix(locations):
    num_locations = len(locations)
    distances = np.zeros((num_locations, num_locations))
    for idx1, l1 in enumerate(locations):
        for idx2, l2 in enumerate(locations):
            distances[idx1, idx2] = haversine(l1[0], l1[1], l2[0], l2[1])

    return distances

def create_data_model(distances, origen, n_vehicles = 1):
    """Creates data structure with dimensions, num vehicles and the origin."""
    data = {}
    data["distances"] = distances
    data['num_locations'] = len(distances)
    data['num_vehicles'] = n_vehicles
    data['depot'] = origen
    return data

def create_distance_callback(data):
    """Creates callback to return distance between points."""

    distances = data['distances']
    def distance_callback(from_node, to_node):
        """Returns the manhattan distance between the two nodes"""
        return distances[from_node][to_node]
    return distance_callback


def add_distance_dimension(routing, distance_callback):
    """Add Global Span constraint"""
    distance = 'Distance'
    maximum_distance = 10000  # Maximum distance per vehicle.
    routing.AddDimension(distance_callback, 0, maximum_distance, True,
                         distance)  # null slack
                                    # start cumul to zero
    distance_dimension = routing.GetDimensionOrDie(distance)
    # Try to minimize the max distance among vehicles.

    distance_dimension.SetGlobalSpanCostCoefficient(100)


def print_solution(data, routing, assignment):
    """Print routes on console."""

    optimization_routes = []
    total_distance = 0
    for vehicle_id in range(data['num_vehicles']):
        vehicle_nodes = []
        index = routing.Start(vehicle_id)
        plan_output = 'Route for vehicle {}:\n'.format(vehicle_id)
        route_dist = 0
        while not routing.IsEnd(index):
            node_index = routing.IndexToNode(index)
            next_node_index = \
                routing.IndexToNode(assignment.Value(routing.NextVar(index)))
            route_dist += routing.GetArcCostForVehicle(node_index,
                    next_node_index, vehicle_id)
            plan_output += ' {0} ->'.format(node_index)
            index = assignment.Value(routing.NextVar(index))
            vehicle_nodes.append(node_index)
        plan_output += ' {}\n'.format(routing.IndexToNode(index))
        plan_output += 'Distance of route: {} km\n'.format(route_dist)
        print(plan_output)
        total_distance += route_dist
        optimization_routes.append(vehicle_nodes)
    print('Total distance of all routes: {} km'.format(total_distance))
    return optimization_routes


def optimize_route_by_distance(locations, names, origin, n_vehicles):
    print("Computing distance matrix...")
    distances = build_distance_matrix(locations)

    print("Creating data model...")
    data = create_data_model(distances, origin, n_vehicles = n_vehicles)

    # Create Routing Model
    routing = pywrapcp.RoutingModel(
      data["num_locations"],
      data["num_vehicles"],
      data["depot"])

    # Define weight of each edge
    distance_callback = create_distance_callback(data)
    routing.SetArcCostEvaluatorOfAllVehicles(distance_callback)
    add_distance_dimension(routing, distance_callback)

    # Setting first solution heuristic (cheapest addition).
    search_parameters = pywrapcp.RoutingModel.DefaultSearchParameters()
    search_parameters.first_solution_strategy = (
        routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC) # pylint: disable=no-member

    # Solve the problem.
    print("Solving...")
    print("\n")
    assignment = routing.SolveWithParameters(search_parameters)
    if assignment:
        routes = print_solution(data, routing, assignment)

    #print(routes)
    for v_idx, vehicle in enumerate(routes):
        plan_names = ""
        for n_idx, n in enumerate(vehicle):
            plan_names += "[{}]: {} ->".format(n, names[n])
        plan_names += "[0]: {}".format(names[0])
        print("Plan for vehicle {}:{}".format(v_idx, plan_names))
        
    return routes
